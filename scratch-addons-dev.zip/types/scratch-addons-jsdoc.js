/**
 * @fileoverview ScratchAddons API JSDoc references to real implementations
 * References actual ScratchAddons classes instead of duplicating definitions
 */

// Reference the actual implementation files for better IntelliSense
/// <reference path="../addon-api/content-script/Addon.js" />
/// <reference path="../addon-api/common/Addon.js" />

/**
 * Import the actual UserscriptAddon class - this is what gets passed to userscripts
 * @typedef {import('../addon-api/content-script/Addon.js').default} UserscriptAddon
 */

/**
 * Augment the Trap class to provide proper return types for its methods
 * This adds type information that the original Trap.js doesn't have
 * @typedef {Object} TrapMethods
 * @property {function(): Promise<typeof import('blockly')>} getBlockly - Gets Blockly instance
 * @property {function(): import('blockly').WorkspaceSvg|null} getWorkspace - Gets Blockly workspace
 * @property {*} vm - Scratch VM instance
 * @property {function(): Promise<*>} getPaper - Gets Paper.js instance
 */

/**
 * Message function for localization - based on actual implementation
 * @typedef {Object} MessageFunction
 * @property {function(string, Object=): string} msg - Get translated message (key, placeholders)
 * @property {string} locale - Current locale (e.g., 'en', 'es', etc.)
 */

/**
 * Enhanced console with addon-specific logging methods
 * @typedef {Object} AddonConsole
 * @property {function(...*): void} log - Standard console.log plus addon-specific logging
 * @property {function(...*): void} warn - Standard console.warn plus addon-specific logging
 * @property {function(...*): void} error - Standard console.error plus addon-specific logging
 */

/**
 * Addon context with all parameters that are actually passed to userscripts
 * Based on the real implementation in content-scripts/inject/run-userscript.js
 * @typedef {Object} AddonContext
 * @property {UserscriptAddon} addon - The actual UserscriptAddon instance with all real properties
 * @property {Console & AddonConsole} console - Enhanced console with addon-specific logging
 * @property {MessageFunction & function(string, Object=): string} msg - Localization function with locale property
 * @property {function(string, Object=): string} safeMsg - Safe localization function that escapes HTML
 */
