// Global type definitions for ScratchAddons development
// Reserved for future global type augmentations if needed

export {};
