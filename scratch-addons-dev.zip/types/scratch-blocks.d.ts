/**
 * Type definitions for scratch-blocks (Scratch's fork of Blockly)
 *
 * This file provides TypeScript definitions for the scratch-blocks library,
 * which is Scratch's customized fork of Google Blockly. It includes both
 * "old Blockly" and "new Blockly" APIs.
 *
 * Feature detection: Check `Blockly.registry` to detect new Blockly version
 */

declare namespace ScratchBlocks {
  // ============================================================================
  // Core Blockly namespace
  // ============================================================================

  /**
   * Registry for new Blockly - if this exists, you're using new Blockly
   */
  export const registry: Registry | undefined;

  /**
   * Hide all context menus, dropdowns, and other UI elements
   */
  export function hideChaff(): void;

  /**
   * Get the main workspace
   */
  export function getMainWorkspace(): WorkspaceSvg;

  // ============================================================================
  // Events
  // ============================================================================

  export namespace Events {
    /**
     * Disable event recording (e.g., for batched operations)
     */
    export function disable(): void;

    /**
     * Enable event recording
     */
    export function enable(): void;

    /**
     * Check if events are currently enabled
     */
    export function isEnabled(): boolean;

    /**
     * Fire an event
     */
    export function fire(event: Abstract): void;

    /**
     * Set the event group (for grouping related events)
     */
    export function setGroup(state: boolean | string): void;

    /**
     * Abstract base class for events
     */
    export class Abstract {
      workspaceId?: string;
      group?: string;
      recordUndo?: boolean;

      /**
       * Encode the event as JSON
       */
      toJson(): any;

      /**
       * Decode the event from JSON
       */
      fromJson(json: any): void;

      /**
       * Does this event record any change of state?
       */
      isNull(): boolean;

      /**
       * Run the event (apply the change)
       */
      run(forward: boolean): void;
    }

    /**
     * Block creation event
     */
    export class BlockCreate extends Abstract {
      constructor(block: BlockSvg);

      type: string;
      blockId?: string;
      xml?: Element;
      ids?: string[];
      json?: any;
    }

    /**
     * Block change event
     */
    export class BlockChange extends Abstract {
      constructor(block: BlockSvg, element: string, name: string | null, oldValue: any, newValue: any);

      blockId?: string;
      element?: string;
      name?: string | null;
      oldValue?: any;
      newValue?: any;
    }

    /**
     * Block delete event
     */
    export class BlockDelete extends Abstract {
      constructor(block: BlockSvg);

      blockId?: string;
      oldXml?: Element;
      ids?: string[];
      oldJson?: any;
    }

    /**
     * Block move event
     */
    export class BlockMove extends Abstract {
      constructor(block: BlockSvg);

      blockId?: string;
      oldParentId?: string;
      oldInputName?: string;
      oldCoordinate?: Coordinate;
      newParentId?: string;
      newInputName?: string;
      newCoordinate?: Coordinate;
    }

    /**
     * UI event (e.g., block selected, workspace clicked)
     */
    export class Ui extends Abstract {
      constructor(block: BlockSvg | null, element: string, oldValue: any, newValue: any);

      blockId?: string | null;
      element?: string;
      oldValue?: any;
      newValue?: any;
    }

    /**
     * Variable creation event
     */
    export class VarCreate extends Abstract {
      constructor(variable: VariableModel);

      varId?: string;
      varName?: string;
      varType?: string;
    }

    /**
     * Variable deletion event
     */
    export class VarDelete extends Abstract {
      constructor(variable: VariableModel);

      varId?: string;
      varName?: string;
      varType?: string;
    }

    /**
     * Variable rename event
     */
    export class VarRename extends Abstract {
      constructor(variable: VariableModel, newName: string);

      varId?: string;
      oldName?: string;
      newName?: string;
    }

    /**
     * Comment creation event (new Blockly)
     */
    export class CommentCreate extends Abstract {
      constructor(comment: any);
    }

    /**
     * Comment change event (new Blockly)
     */
    export class CommentChange extends Abstract {
      constructor(comment: any, element: string, oldValue: any, newValue: any);
    }

    /**
     * Comment deletion event (new Blockly)
     */
    export class CommentDelete extends Abstract {
      constructor(comment: any);
    }

    /**
     * Comment move event (new Blockly)
     */
    export class CommentMove extends Abstract {
      constructor(comment: any);
    }
  }

  // ============================================================================
  // Blocks
  // ============================================================================

  /**
   * Base class for all blocks
   */
  export class Block {
    id: string;
    type: string;
    disabled?: boolean;
    comment?: string;
    collapsed?: boolean;
    inputsInline?: boolean;
    data?: string;
    extraState?: any;

    /**
     * Get the block's ID (old Blockly uses method, new uses property)
     */
    getId?(): string;

    /**
     * Get all descendant blocks
     */
    getDescendants(ordered?: boolean): Block[];

    /**
     * Get child blocks
     */
    getChildren(ordered?: boolean): Block[];

    /**
     * Get variables used by this block
     */
    getVarModels(): VariableModel[];

    /**
     * Get variables (old API)
     */
    getVars?(): string[];

    /**
     * Get the procedure code (for procedure blocks)
     */
    getProcCode?(): string;

    /**
     * Move the block by a delta
     */
    moveBy(dx: number, dy: number): void;

    /**
     * Get parent block
     */
    getParent(): Block | null;

    /**
     * Get next block
     */
    getNextBlock(): Block | null;

    /**
     * Get previous block
     */
    getPreviousBlock(): Block | null;

    /**
     * Get the top-level block in this stack
     */
    getRootBlock(): Block;

    /**
     * Get surrounding block
     */
    getSurroundParent(): Block | null;

    /**
     * Get input with the given name
     */
    getInput(name: string): Input | null;

    /**
     * Get field with the given name
     */
    getField(name: string): Field | null;

    /**
     * Get field value
     */
    getFieldValue(name: string): any;

    /**
     * Set field value
     */
    setFieldValue(newValue: any, name: string): void;

    /**
     * Dispose of this block
     */
    dispose(healStack?: boolean): void;

    /**
     * Check if block is disposable
     */
    isDisposable(): boolean;

    /**
     * Check if block is movable
     */
    isMovable(): boolean;

    /**
     * Check if block is editable
     */
    isEditable(): boolean;

    /**
     * Check if block is deletable
     */
    isDeletable(): boolean;

    /**
     * Check if block is a shadow block
     */
    isShadow(): boolean;

    /**
     * Check if block is collapsed
     */
    isCollapsed(): boolean;

    /**
     * Input list
     */
    inputList: Input[];

    /**
     * Output connection
     */
    outputConnection: Connection | null;

    /**
     * Previous connection
     */
    previousConnection: Connection | null;

    /**
     * Next connection
     */
    nextConnection: Connection | null;

    /**
     * Workspace containing this block
     */
    workspace: Workspace;
  }

  /**
   * SVG representation of a block
   */
  export class BlockSvg extends Block {
    /**
     * Path object (new Blockly)
     */
    pathObject?: {
      svgPath: SVGElement;
      svgPathSelected?: SVGElement;
      outlines?: Map<string, SVGElement>;
    };

    /**
     * SVG path (old Blockly)
     */
    svgPath_?: SVGElement;

    /**
     * Check if block is in the flyout
     */
    isInFlyout?: boolean;

    /**
     * Get the SVG root element for this block
     */
    getSvgRoot(): SVGElement;

    /**
     * Get position relative to workspace surface
     */
    getRelativeToSurfaceXY(): Coordinate;

    /**
     * Select this block
     */
    select(): void;

    /**
     * Unselect this block
     */
    unselect(): void;

    /**
     * Initialize the SVG representation
     */
    initSvg(): void;

    /**
     * Render the block
     */
    render(optBubble?: boolean): void;

    /**
     * Apply colors to the block (new Blockly)
     */
    applyColour?(): void;

    /**
     * Update colors (old Blockly)
     */
    updateColour?(): void;

    /**
     * Set whether the block is collapsed
     */
    setCollapsed(collapsed: boolean): void;

    /**
     * Set whether the block is highlighted
     */
    setHighlighted(highlighted: boolean): void;

    /**
     * Add select event
     */
    addSelect(): void;

    /**
     * Remove select event
     */
    removeSelect(): void;

    /**
     * Set parent
     */
    setParent(newParent: BlockSvg | null): void;

    /**
     * Dispose of the block's SVG
     */
    dispose(healStack?: boolean, animate?: boolean): void;

    /**
     * Generate context menu for new Blockly
     */
    generateContextMenu?(): ContextMenuOption[];

    /**
     * Custom context menu function (old Blockly)
     */
    customContextMenu?(options: ContextMenuOption[]): void;
  }

  // ============================================================================
  // Workspace
  // ============================================================================

  /**
   * Base workspace class
   */
  export class Workspace {
    id: string;

    /**
     * Get all top-level blocks
     */
    getTopBlocks(ordered?: boolean): Block[];

    /**
     * Get all blocks in the workspace
     */
    getAllBlocks(ordered?: boolean): Block[];

    /**
     * Get block by ID
     */
    getBlockById(id: string): Block | null;

    /**
     * Get variable map
     */
    getVariableMap(): VariableMap;

    /**
     * Get variable by name and type
     */
    getVariable(name: string, type?: string): VariableModel | null;

    /**
     * Get variable by ID
     */
    getVariableById(id: string): VariableModel | null;

    /**
     * Create variable
     */
    createVariable(name: string, type?: string, id?: string): VariableModel | null;

    /**
     * Delete variable by ID
     */
    deleteVariableById(id: string): void;

    /**
     * Rename variable by ID
     */
    renameVariableById(id: string, newName: string): void;

    /**
     * Clear the workspace
     */
    clear(): void;

    /**
     * Undo
     */
    undo(redo?: boolean): void;

    /**
     * Clear undo stack
     */
    clearUndo(): void;

    /**
     * Max blocks limit
     */
    remainingCapacity(): number;

    /**
     * Check if workspace is capable of certain capacity
     */
    isCapacityAvailable(blocks: Block[]): boolean;
  }

  /**
   * SVG workspace with UI
   */
  export class WorkspaceSvg extends Workspace {
    /**
     * Scroll to a position
     */
    scroll(x: number, y: number): void;

    /**
     * Scrollbar (if exists)
     */
    scrollbar?: {
      setY(y: number): void;
      setX(x: number): void;
    };

    /**
     * Scale of the workspace
     */
    scale: number;

    /**
     * Zoom to fit
     */
    zoomToFit(): void;

    /**
     * Set zoom
     */
    setScale(newScale: number): void;

    /**
     * Zoom center
     */
    zoom(x: number, y: number, amount: number): void;

    /**
     * Zoom in
     */
    zoomIn(): void;

    /**
     * Zoom out
     */
    zoomOut(): void;

    /**
     * Zoom reset
     */
    zoomReset(): void;

    /**
     * Set resizes enabled
     */
    setResizesEnabled(enabled: boolean): void;

    /**
     * Resize workspace
     */
    resize(): void;

    /**
     * Get current gesture (new Blockly)
     */
    getGesture?(e: Event): Gesture | null;

    /**
     * Start drag with fake event (old Blockly)
     */
    startDragWithFakeEvent?(e: any, block: BlockSvg): void;

    /**
     * Check if coordinates are in delete area (old Blockly)
     */
    isDeleteArea?(e: Event): number | null;

    /**
     * Get component manager (new Blockly)
     */
    getComponentManager?(): ComponentManager;

    /**
     * Record drag targets (new Blockly)
     */
    recordDragTargets?(): void;

    /**
     * Current gesture (old Blockly)
     */
    currentGesture_?: Gesture;

    /**
     * Get metrics for scrollbar
     */
    getMetrics?(): {
      viewHeight: number;
      viewWidth: number;
      contentHeight: number;
      contentWidth: number;
      viewTop: number;
      viewLeft: number;
      contentTop: number;
      contentLeft: number;
      absoluteTop: number;
      absoluteLeft: number;
    };

    /**
     * Highlight a block
     */
    highlightBlock(id: string | null): void;

    /**
     * Get canvas
     */
    getCanvas(): SVGElement;

    /**
     * Get bubble canvas
     */
    getBubbleCanvas(): SVGElement;

    /**
     * Get parent SVG
     */
    getParentSvg(): SVGElement;

    /**
     * Add change listener
     */
    addChangeListener(func: (event: Events.Abstract) => void): Function;

    /**
     * Remove change listener
     */
    removeChangeListener(func: Function): void;

    /**
     * Fire change listener (old Blockly)
     */
    fireChangeListener?(event: Events.Abstract): void;

    /**
     * Get toolbox
     */
    getToolbox?(): Toolbox | null;

    /**
     * Get flyout
     */
    getFlyout?(): Flyout | null;

    /**
     * Refresh toolbox selection
     */
    refreshToolboxSelection?(): void;

    /**
     * Update toolbox
     */
    updateToolbox?(tree: any): void;
  }

  // ============================================================================
  // Gesture (for handling mouse/touch interactions)
  // ============================================================================

  export class Gesture {
    /**
     * Most recent event (new Blockly)
     */
    mostRecentEvent?: MouseEvent | TouchEvent;

    /**
     * Most recent event (old Blockly)
     */
    mostRecentEvent_?: MouseEvent | TouchEvent;

    /**
     * Start block (new Blockly)
     */
    startBlock?: BlockSvg;

    /**
     * Start block (old Blockly)
     */
    startBlock_?: BlockSvg;

    /**
     * Start field (new Blockly)
     */
    startField?: Field;

    /**
     * Start field (old Blockly)
     */
    startField_?: Field;

    /**
     * Start workspace
     */
    startWorkspace?: WorkspaceSvg;

    /**
     * Start workspace (old)
     */
    startWorkspace_?: WorkspaceSvg;

    /**
     * Flyout
     */
    flyout_?: Flyout;

    /**
     * Start bubble
     */
    startBubble_?: any;

    /**
     * Is this gesture dragging?
     */
    dragging?: boolean;

    /**
     * Has the gesture exceeded drag radius?
     */
    hasExceededDragRadius?: boolean;

    /**
     * The dragger object
     */
    dragger?: any;

    /**
     * Gesture has started flag
     */
    gestureHasStarted?: boolean;

    /**
     * Handle block start (new Blockly)
     */
    handleBlockStart?(e: Event | any, block: BlockSvg): void;

    /**
     * Handle workspace start (new Blockly)
     */
    handleWsStart?(e: Event | any, workspace: WorkspaceSvg): void;

    /**
     * Create dragger (new Blockly)
     */
    createDragger?(block: BlockSvg | WorkspaceSvg, workspace?: WorkspaceSvg): any;

    /**
     * Do block click (new Blockly)
     */
    doBlockClick?(): void;

    /**
     * Do block click (old Blockly)
     */
    doBlockClick_?(): void;

    /**
     * Do workspace click (new Blockly)
     */
    doWorkspaceClick?(): void;

    /**
     * Do workspace click (old Blockly)
     */
    doWorkspaceClick_?(): void;
  }

  // ============================================================================
  // Touch (for handling touch events)
  // ============================================================================

  export namespace Touch {
    /**
     * Clear touch identifier
     */
    export function clearTouchIdentifier(): void;

    /**
     * Check touch identifier
     */
    export function checkTouchIdentifier(e: any): void;
  }

  // ============================================================================
  // Utils
  // ============================================================================

  export namespace utils {
    /**
     * Coordinate class
     */
    export class Coordinate {
      constructor(x: number, y: number);
      x: number;
      y: number;
    }

    /**
     * Rectangle class (new Blockly)
     */
    export class Rect {
      constructor(top: number, bottom: number, left: number, right: number);
      top: number;
      bottom: number;
      left: number;
      right: number;
    }

    /**
     * Check if target is input (old Blockly)
     */
    export function isTargetInput(e: Event): boolean;

    /**
     * XML utilities (new Blockly)
     */
    export namespace xml {
      export function createElement(tagName: string): Element;
      export function textToDom(text: string): Element;
      export function domToText(dom: Element): string;
    }

    /**
     * Colour utilities
     */
    export namespace colour {
      export function hsvToHex(h: number, s: number, v: number): string;
      export function hexToRgb(hex: string): number[];
    }
  }

  /**
   * Browser events (new Blockly)
   */
  export namespace browserEvents {
    /**
     * Check if target is input
     */
    export function isTargetInput(e: Event): boolean;
  }

  // ============================================================================
  // Scratch-specific utilities
  // ============================================================================

  export namespace scratchBlocksUtils {
    /**
     * Change obscured shadow IDs (prevents ID collisions when copying)
     */
    export function changeObscuredShadowIds(block: Block): void;
  }

  // ============================================================================
  // Variables
  // ============================================================================

  export class VariableModel {
    /**
     * Variable name
     */
    name: string;

    /**
     * Variable type
     */
    type: string;

    /**
     * Variable ID
     */
    id_?: string;

    /**
     * Whether this is a local variable (Scratch-specific)
     */
    isLocal?: boolean;

    /**
     * Get the variable ID
     */
    getId(): string;

    /**
     * Get the variable name
     */
    getName(): string;

    /**
     * Get the variable type
     */
    getType(): string;
  }

  export class VariableMap {
    /**
     * Get all variables
     */
    getAllVariables(): VariableModel[];

    /**
     * Get variables of a specific type
     */
    getVariablesOfType(type: string): VariableModel[];

    /**
     * Get variable by name
     */
    getVariable(name: string, type?: string): VariableModel | null;

    /**
     * Get variable by ID
     */
    getVariableById(id: string): VariableModel | null;

    /**
     * Create variable
     */
    createVariable(name: string, type?: string, id?: string): VariableModel | null;

    /**
     * Delete variable
     */
    deleteVariable(variable: VariableModel): void;

    /**
     * Delete variable by ID
     */
    deleteVariableById(id: string): void;

    /**
     * Rename variable
     */
    renameVariable(variable: VariableModel, newName: string): void;

    /**
     * Rename variable by ID
     */
    renameVariableById(id: string, newName: string): void;
  }

  // ============================================================================
  // Fields
  // ============================================================================

  export class Field {
    /**
     * Field name
     */
    name: string;

    /**
     * Field value
     */
    value_?: any;

    /**
     * Source block
     */
    sourceBlock_?: Block;

    /**
     * Get the field value
     */
    getValue(): any;

    /**
     * Set the field value
     */
    setValue(newValue: any): void;

    /**
     * Get text representation
     */
    getText(): string;

    /**
     * Set text
     */
    setText(text: string): void;

    /**
     * Is the field editable?
     */
    isEditable(): boolean;

    /**
     * Set whether the field is editable
     */
    setEditable(editable: boolean): void;

    /**
     * Dispose of the field
     */
    dispose(): void;
  }

  export class FieldImage extends Field {
    /**
     * Image source URL
     */
    src_?: string;
  }

  // ============================================================================
  // Inputs and Connections
  // ============================================================================

  export class Input {
    /**
     * Input type (value, statement, dummy)
     */
    type: number;

    /**
     * Input name
     */
    name: string;

    /**
     * Connection (for value and statement inputs)
     */
    connection: Connection | null;

    /**
     * Field row
     */
    fieldRow: Field[];

    /**
     * Source block
     */
    sourceBlock: Block;

    /**
     * Append field
     */
    appendField(field: Field | string, name?: string): Input;

    /**
     * Insert field at index
     */
    insertFieldAt(index: number, field: Field | string, name?: string): number;

    /**
     * Remove field
     */
    removeField(name: string): void;

    /**
     * Dispose of input
     */
    dispose(): void;
  }

  export class Connection {
    /**
     * Source block
     */
    sourceBlock: Block;

    /**
     * Target connection
     */
    targetConnection: Connection | null;

    /**
     * Target block
     */
    targetBlock(): Block | null;

    /**
     * Check whether this connection is connected
     */
    isConnected(): boolean;

    /**
     * Connect to another connection
     */
    connect(otherConnection: Connection): void;

    /**
     * Disconnect
     */
    disconnect(): void;

    /**
     * Check whether connection is compatible
     */
    checkType_(otherConnection: Connection): boolean;
  }

  // ============================================================================
  // Context Menu
  // ============================================================================

  export namespace ContextMenu {
    /**
     * Show context menu (old Blockly)
     */
    export function show(event: Event, options: ContextMenuOption[], rtl: boolean): void;

    /**
     * Create widget (old Blockly)
     */
    export function createWidget_(options: ContextMenuOption[], rtl: boolean): void;
  }

  export interface ContextMenuOption {
    enabled: boolean;
    text: string;
    callback: () => void;
    separator?: boolean;
  }

  // ============================================================================
  // Registry (new Blockly)
  // ============================================================================

  export class Registry {
    /**
     * Registry types
     */
    static Type: {
      FIELD: string;
      RENDERER: string;
      TOOLBOX: string;
      THEME: string;
      TOOLBOX_ITEM: string;
      FLYOUT: string;
      CURSOR: string;
      CONNECTION_CHECKER: string;
    };

    /**
     * Get a class from the registry
     */
    static getClass(type: string, name: string): any;

    /**
     * Register a class
     */
    static register(type: string, name: string, registryItem: any): void;

    /**
     * Unregister a class
     */
    static unregister(type: string, name: string): boolean;
  }

  // ============================================================================
  // Component Manager (new Blockly)
  // ============================================================================

  export class ComponentManager {
    /**
     * Capabilities
     */
    static Capability: {
      DELETE_AREA: string;
      DRAG_TARGET: string;
      AUTOSCROLL: string;
      POSITIONABLE: string;
    };

    /**
     * Add a component
     */
    addComponent(componentInfo: { component: any; weight: number; capabilities: string[] }): void;

    /**
     * Remove a component
     */
    removeComponent(id: string): void;

    /**
     * Get components with capability
     */
    getComponentsCapability(capability: string): any[];
  }

  // ============================================================================
  // Delete Area (new Blockly)
  // ============================================================================

  export class DeleteArea {
    /**
     * Component ID
     */
    id?: string;

    /**
     * Get the client rect for this delete area
     */
    getClientRect?(): utils.Rect;
  }

  // ============================================================================
  // Drag Target (new Blockly)
  // ============================================================================

  export class DragTarget {
    /**
     * Component ID
     */
    id?: string;

    /**
     * Get the client rect
     */
    getClientRect?(): utils.Rect;

    /**
     * Handle drag over
     */
    onDragOver?(dragElement: any): void;

    /**
     * Handle drag exit
     */
    onDragExit?(dragElement: any): void;

    /**
     * Handle drop
     */
    onDrop?(dragElement: any): void;

    /**
     * Should the delete area be highlighted?
     */
    shouldPreventMove?(dragElement: any): boolean;
  }

  // ============================================================================
  // Widget Div
  // ============================================================================

  export namespace WidgetDiv {
    /**
     * The widget div element (old Blockly)
     */
    export const DIV: HTMLDivElement;

    /**
     * Get the widget div (new Blockly)
     */
    export function getDiv(): HTMLDivElement;

    /**
     * Show the widget div
     */
    export function show(newOwner: any, rtl: boolean, dispose: () => void): void;

    /**
     * Hide the widget div
     */
    export function hide(): void;

    /**
     * Is the widget div showing?
     */
    export function isVisible(): boolean;
  }

  // ============================================================================
  // Toolbox
  // ============================================================================

  export class Toolbox {
    /**
     * Get selected item
     */
    getSelectedItem(): any;

    /**
     * Set selected item
     */
    setSelectedItem(item: any, shouldScroll?: boolean): void;

    /**
     * Clear selection
     */
    clearSelection(): void;

    /**
     * Refresh selection
     */
    refreshSelection(): void;
  }

  // ============================================================================
  // Flyout
  // ============================================================================

  export class Flyout {
    /**
     * Workspace for the flyout
     */
    workspace_: WorkspaceSvg;

    /**
     * Is the flyout visible?
     */
    isVisible(): boolean;

    /**
     * Show the flyout
     */
    show(xmlList: Element[] | string): void;

    /**
     * Hide the flyout
     */
    hide(): void;

    /**
     * Get workspace
     */
    getWorkspace(): WorkspaceSvg;

    /**
     * Position the flyout
     */
    position(): void;

    /**
     * Scroll to start
     */
    scrollToStart(): void;
  }

  // ============================================================================
  // Constants
  // ============================================================================

  /**
   * Delete area types (old Blockly)
   */
  export const DELETE_AREA_TRASH: number;
  export const DELETE_AREA_TOOLBOX: number;
  export const DELETE_AREA_NONE: number;

  /**
   * Input types
   */
  export const INPUT_VALUE: number;
  export const OUTPUT_VALUE: number;
  export const NEXT_STATEMENT: number;
  export const PREVIOUS_STATEMENT: number;
  export const DUMMY_INPUT: number;

  /**
   * Connection types
   */
  export const CONNECTION_TYPE_INPUT: number;
  export const CONNECTION_TYPE_OUTPUT: number;
  export const CONNECTION_TYPE_NEXT: number;
  export const CONNECTION_TYPE_PREVIOUS: number;
}

// Export as both a namespace and a value (for runtime checks)
declare const ScratchBlocks: typeof ScratchBlocks;
export = ScratchBlocks;
export as namespace Blockly;
