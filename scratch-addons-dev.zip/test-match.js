function smartMatch(searchText, targetText) {
  const rawTokens = searchText.split(/\s+/).filter(t => t.length > 0);
  const tokens = [];
  
  for (const rawToken of rawTokens) {
    const camelSplit = rawToken.split(/(?=[A-Z])/).filter(t => t.length > 0);
    tokens.push(...camelSplit.map(t => t.toLowerCase()));
  }
  
  console.log('Tokens:', tokens);
  
  if (tokens.length === 0) return [];

  const targetLower = targetText.toLowerCase();
  const matches = [];
  let searchPos = 0;

  for (const token of tokens) {
    let found = false;
    console.log(`\nSearching for token "${token}" starting from position ${searchPos}`);
    
    for (let i = searchPos; i < targetText.length; i++) {
      const isWordStart = 
        i === 0 ||
        targetText[i - 1] === ' ' ||
        targetText[i - 1] === '_' ||
        (i > 0 && 
         targetText[i - 1] >= 'a' && targetText[i - 1] <= 'z' &&
         targetText[i] >= 'A' && targetText[i] <= 'Z');

      if (isWordStart) {
        const matchesHere = targetLower.substr(i, token.length) === token;
        console.log(`  Position ${i} (${targetText[i]}): word start, matches="${matchesHere}"`);
        if (matchesHere) {
          matches.push({ start: i, length: token.length });
          searchPos = i + token.length;
          found = true;
          break;
        }
      }
    }

    if (!found) {
      console.log(`  Token "${token}" not found`);
      return null;
    }
  }

  return matches;
}

console.log('\n=== Test 1: "gD" vs "get Distance" ===');
console.log(smartMatch("gD", "get Distance"));

console.log('\n=== Test 2: "gD" vs "get distance" ===');
console.log(smartMatch("gD", "get distance"));

console.log('\n=== Test 3: "g D" vs "get Distance" ===');
console.log(smartMatch("g D", "get Distance"));
